# ArchModelRoom
Implementacion de Room en MVVM Aplicacion Android

Uso de la Arquitectura MVVM para la implementacion de proyecto con Base de Datos local

Contiene una Base de Datos SQLite con las implementaciones suficientes (Activities, Adapters, Daos, Entities, Repositories, ViewModels)
para una sola clase, pudiendo extender las que se necesiten
